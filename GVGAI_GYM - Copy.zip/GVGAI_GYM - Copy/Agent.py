from random import randint
import RNN as rnn

class Agent():
    def __init__(self):
        self.name = "randomAgent"

    def act(self, stateObs, actions):
        #code = drsc(stateObs)
        #act_res =  rnn(code, weight)
        #select best act from act_res (select(act_res))
        action_id = randint(0,len(actions)-1)
        return action_id
    
'''
class RNNAgent(Agent):
    def __init__(self, drsc_dict, W=None , U=None, b=None, epsilon=0.1, omega=32):
        self.name = "rnnagent"
        self.dict = drsc_dict
        self.rnn = rnn.RNN(W, U, b)
        self.epsilon = epsilon
        self.omega = omega
        

    def act(self, stateObs, actions):
        stateCode = self.drsc(stateObs, self.dict)
        action_id = self.rnn.act(stateCode)
        return action_id

    def drsc(self, stateObs, drsc_dict):               
        p = stateObs
        w = 0
        c=[]
        while p > self.epsilon and w < self.omega:
            res = []
            for d in drsc_dict:
                res.append(self.sim(p,d))
                #sim function
            msc = res.index(max(res))
            c[msc] = 1
            w = w+1
            p=p-drsc_dict[msc]
            for i in p:
                i = max(0,i)
        #return c
        return [randint(0,1) for n in range(min(self.omega, len(drsc_dict)))]
    
    def sim(self, p, d):
        return 1
        #return [n for n in range(32)]
'''